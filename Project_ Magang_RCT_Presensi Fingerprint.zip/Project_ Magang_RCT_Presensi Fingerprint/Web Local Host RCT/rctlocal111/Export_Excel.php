<?php
// Hubungkan ke database melewati script connectDB.php
require'connectDB.php';

$output = '';
//
if(isset($_POST["To_Excel"])){ //Dengan script ini user dapat export data mereka ke Excel
  
    if ( empty($_POST['date_sel'])) {

        $Log_date = date("Y-m-d");
    }
    else if ( !empty($_POST['date_sel'])) {

        $Log_date = $_POST['date_sel']; 
    }
        $sql = "SELECT * FROM users_logs WHERE checkindate='$Log_date' ORDER BY id DESC"; //Memilih database mana yang ingin di export
        $result = mysqli_query($conn, $sql);
        if($result->num_rows > 0){ 
//<!-- *********************************************** -->
//Dibawah adalah output dari isi tabel yang akan di catat ke excel
            $output .= ' 
                        <table class="table" bordered="1">  
                          <TR>
                            <TH>ID</TH>
                            <TH>Name</TH>
                            <TH>Serial Number</TH>
                            <TH>Fingerprint ID</TH>
                            <TH>Date log</TH>
                            <TH>Time In</TH>
                            <TH>Time Out</TH>
                          </TR>';
//<!-- *********************************************** -->
              while($row=$result->fetch_assoc()) { 
//<!-- *********************************************** -->
//dibawah adalah barisan tabel dari database yang dimana data dari database ini akan diambil ke excel
                  $output .= ' 

                              <TR> 
                                  <TD> '.$row['id'].'</TD>
                                  <TD> '.$row['username'].'</TD>
                                  <TD> '.$row['serialnumber'].'</TD>
                                  <TD> '.$row['fingerprint_id'].'</TD>
                                  <TD> '.$row['checkindate'].'</TD>
                                  <TD> '.$row['timein'].'</TD>
                                  <TD> '.$row['timeout'].'</TD>
                              </TR>';
              }
              $output .= '</table>';  //output tabel
              header('Content-Type: application/xls'); //output berupa xls
              header('Content-Disposition: attachment; filename=User_Log'.$Log_date.'.xls'); 
//<!-- *********************************************** -->
              echo $output;
              exit();
        }
        else{
            header( "location: UsersLog.php" );
            exit();
        }
}
?>