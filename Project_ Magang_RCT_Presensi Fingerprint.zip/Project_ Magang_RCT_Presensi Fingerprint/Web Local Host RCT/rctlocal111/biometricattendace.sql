-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 08, 2021 at 05:04 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `biometricattendace`
--

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `username` varchar(30) NOT NULL,
  `password` varchar(30) NOT NULL,
  `level` varchar(30) NOT NULL,
  `nama` varchar(30) NOT NULL,
  `id` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`username`, `password`, `level`, `nama`, `id`) VALUES
('icat', 'testing12345', 'Admin', '', 0),
('yosias', 'testing12345', 'pegawai', '', 0),
('richard', 'richard', 'admin', '', 0),
('richard', 'richard', 'admin', 'Richard', 1),
('yosias', 'yosias', 'Karyawan', 'Yosias', 2);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `serialnumber` double NOT NULL,
  `gender` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  `fingerprint_id` int(11) NOT NULL,
  `fingerprint_select` tinyint(1) NOT NULL DEFAULT 0,
  `user_date` date NOT NULL,
  `time_in` time NOT NULL,
  `del_fingerid` tinyint(1) NOT NULL DEFAULT 0,
  `add_fingerid` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `serialnumber`, `gender`, `email`, `fingerprint_id`, `fingerprint_select`, `user_date`, `time_in`, `del_fingerid`, `add_fingerid`) VALUES
(34, 'qqq', 111, 'Male', 'qqq', 3, 0, '2021-11-19', '11:11:00', 0, 0),
(35, 'Richard Chandra Tjiang', 11181073, 'Male', 'icattj@gmail.com', 5, 0, '2021-11-19', '14:57:00', 0, 0),
(39, 'qwertyuiop', 14567890, 'Female', 'qwrtyuiop', 4, 0, '2021-11-22', '04:51:00', 0, 0),
(41, 'Ggggg', 66666, 'Male', 'ggggg', 76, 0, '2021-11-22', '13:52:00', 0, 0),
(42, 'Tjiang Chandra Richard', 17, 'Male', 'tjiangchandrarichard@gmail.com', 19, 0, '2021-11-23', '02:59:00', 0, 0),
(43, 'Chandra Tjiang Richard', 199, 'Male', '12312312312312', 18, 0, '2021-11-23', '12:06:00', 0, 0),
(44, 'Lizwan`', 12345, 'Male', '123456', 21, 0, '2021-11-23', '13:27:00', 0, 0),
(45, 'Chandra Richard Tjiang', 90909090, 'Male', 'blablaba@gmail.com', 22, 0, '2021-11-25', '12:57:00', 0, 0),
(46, 'Yosias ', 4181081, 'Male', 'icattj@gmail.com', 23, 1, '2021-11-25', '13:05:00', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `users_logs`
--

CREATE TABLE `users_logs` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `serialnumber` double NOT NULL,
  `fingerprint_id` int(5) NOT NULL,
  `checkindate` date NOT NULL,
  `timein` time NOT NULL,
  `timeout` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users_logs`
--

INSERT INTO `users_logs` (`id`, `username`, `serialnumber`, `fingerprint_id`, `checkindate`, `timein`, `timeout`) VALUES
(1, 'icat', 123456, 3, '2021-09-14', '12:54:25', '13:26:05'),
(2, 'icat', 123456, 3, '2021-09-14', '13:02:46', '13:26:05'),
(3, 'Yosias', 123456, 1, '2021-09-14', '13:19:45', '14:52:38'),
(4, 'Icat', 654321, 2, '2021-09-14', '13:22:24', '14:03:20'),
(5, 'Choir', 134254, 3, '2021-09-14', '13:25:28', '13:26:05'),
(6, 'Yosias', 123456, 1, '2021-09-14', '13:32:18', '14:52:38'),
(7, 'Yosias', 123456, 1, '2021-09-14', '13:36:02', '14:52:38'),
(8, 'Yosias', 123456, 1, '2021-09-14', '13:36:38', '14:52:38'),
(9, 'Yosias', 123456, 1, '2021-09-14', '13:54:27', '14:52:38'),
(10, 'Yosias', 123456, 1, '2021-09-14', '14:01:24', '14:52:38'),
(11, 'icat', 543216, 2, '2021-09-14', '14:03:05', '14:03:20'),
(12, 'Yosias', 123456, 1, '2021-09-14', '14:45:52', '14:52:38'),
(13, 'Yosias', 123456, 1, '2021-09-14', '14:49:52', '14:52:38'),
(14, 'Yosias', 123456, 1, '2021-09-14', '14:52:21', '14:52:38'),
(15, 'Yosias', 123456, 1, '2021-09-16', '16:07:55', '16:14:43'),
(16, 'icat', 543216, 2, '2021-09-16', '16:08:42', '16:15:22'),
(17, 'Yosias', 123456, 1, '2021-09-16', '16:12:38', '16:14:43'),
(18, 'icat', 543216, 2, '2021-09-16', '16:13:24', '16:15:22'),
(19, 'dika', 82255, 3, '2021-09-21', '14:03:55', '15:29:29'),
(20, 'dika', 82255, 3, '2021-09-21', '14:04:28', '15:29:29'),
(21, 'dika', 82255, 3, '2021-09-21', '14:05:27', '15:29:29'),
(22, 'dika', 82255, 3, '2021-09-21', '14:06:14', '15:29:29'),
(23, 'dika', 82255, 3, '2021-09-21', '14:07:24', '15:29:29'),
(24, 'dika', 82255, 3, '2021-09-21', '14:08:04', '15:29:29'),
(25, 'dika', 82255, 3, '2021-09-21', '14:08:45', '15:29:29'),
(26, 'dika', 82255, 3, '2021-09-21', '14:09:20', '15:29:29'),
(27, 'dika', 82255, 3, '2021-09-21', '14:09:49', '15:29:29'),
(28, 'dika', 82255, 3, '2021-09-21', '14:11:06', '15:29:29'),
(29, 'dika', 82255, 3, '2021-09-21', '14:11:42', '15:29:29'),
(30, 'dika', 82255, 3, '2021-09-21', '14:12:52', '15:29:29'),
(31, 'dika', 82255, 3, '2021-09-21', '14:13:28', '15:29:29'),
(32, 'dika', 82255, 3, '2021-09-21', '14:15:10', '15:29:29'),
(33, 'Yosias', 123456, 1, '2021-09-21', '14:16:25', '16:15:18'),
(34, 'Yosias', 123456, 1, '2021-09-21', '14:17:24', '16:15:18'),
(35, 'Yosias', 123456, 1, '2021-09-21', '14:19:55', '16:15:18'),
(36, 'Yosias', 123456, 1, '2021-09-21', '14:20:41', '16:15:18'),
(37, 'dika', 82255, 3, '2021-09-21', '14:21:47', '15:29:29'),
(38, 'dika', 82255, 3, '2021-09-21', '14:22:36', '15:29:29'),
(39, 'Yosias', 123456, 1, '2021-09-21', '14:22:59', '16:15:18'),
(40, 'dika', 82255, 3, '2021-09-21', '14:24:41', '15:29:29'),
(41, 'Aji', 5453534, 4, '2021-09-21', '14:45:32', '14:45:49'),
(42, 'dika', 82255, 3, '2021-09-21', '14:46:13', '15:29:29'),
(43, 'Dimas', 23472372, 1, '2021-09-21', '15:10:16', '16:15:18'),
(44, 'icat', 23492349, 2, '2021-09-21', '15:24:58', '15:25:12'),
(45, 'icat', 23492349, 2, '2021-09-21', '15:25:31', '00:00:00'),
(46, 'yos', 23723742, 3, '2021-09-21', '15:29:17', '15:29:29'),
(47, 'adi', 84546, 4, '2021-09-21', '16:11:29', '00:00:00'),
(48, 'Dimas', 23472372, 1, '2021-09-21', '16:12:00', '16:15:18'),
(49, 'dita', 123321, 1, '2021-09-21', '16:14:58', '16:15:18'),
(50, 'rida', 1232423, 2, '2021-09-23', '11:46:36', '00:00:00'),
(51, 'mika', 232342, 3, '2021-09-24', '11:16:50', '11:17:09'),
(52, 'nia', 3473475345, 4, '2021-09-24', '11:24:33', '11:25:03'),
(53, 'mika', 232342, 3, '2021-09-24', '11:25:59', '00:00:00'),
(54, 'rima', 4586496405, 5, '2021-09-24', '11:27:25', '11:27:38'),
(55, 'dia', 34534853486, 6, '2021-09-24', '11:40:23', '11:40:36'),
(56, 'qqq', 111, 3, '2021-11-19', '14:55:09', '14:56:32'),
(57, 'Richard Chandra Tjiang', 11181073, 5, '2021-11-19', '14:57:56', '14:58:40'),
(58, 'qqq', 111, 3, '2021-11-22', '11:52:22', '11:58:44'),
(59, 'Richard Chandra Tjiang', 11181073, 5, '2021-11-22', '11:52:30', '11:53:12'),
(60, 'qwertyuiop', 14567890, 4, '2021-11-22', '11:52:36', '15:03:48'),
(61, 'yosias', 8888, 6, '2021-11-22', '11:56:37', '11:56:50'),
(62, 'qqq', 111, 3, '2021-11-22', '11:57:11', '11:58:44'),
(63, 'qqq', 111, 3, '2021-11-22', '11:58:35', '11:58:44'),
(64, 'Ggggg', 66666, 76, '2021-11-22', '13:51:00', '13:52:25'),
(65, 'Ggggg', 66666, 76, '2021-11-22', '15:02:26', '00:00:00'),
(66, 'qwertyuiop', 14567890, 4, '2021-11-22', '15:03:26', '15:03:48'),
(67, 'Tjiang Chandra Richard', 17, 19, '2021-11-23', '12:00:00', '12:07:42'),
(68, 'qqq', 111, 3, '2021-11-23', '12:01:18', '12:06:45'),
(69, 'qwertyuiop', 14567890, 4, '2021-11-23', '12:01:50', '12:01:59'),
(70, 'Tjiang Chandra Richard', 17, 19, '2021-11-23', '12:02:21', '12:07:42'),
(71, 'qqq', 111, 3, '2021-11-23', '12:05:38', '12:06:45'),
(72, 'Chandra Tjiang Richard', 199, 18, '2021-11-23', '12:06:13', '12:06:57'),
(73, 'Tjiang Chandra Richard', 17, 19, '2021-11-23', '12:07:26', '12:07:42'),
(74, 'Tjiang Chandra Richard', 17, 19, '2021-11-23', '12:07:45', '00:00:00'),
(75, 'qqq', 111, 3, '2021-11-23', '12:08:05', '00:00:00'),
(76, 'Ggggg', 66666, 76, '2021-11-23', '13:29:30', '14:14:35'),
(77, 'Lizwan`', 12345, 21, '2021-11-23', '13:30:51', '00:00:00'),
(78, 'Ggggg', 66666, 76, '2021-11-23', '14:14:17', '14:14:35'),
(79, 'Chandra Richard Tjiang', 90909090, 22, '2021-11-25', '12:58:27', '12:59:56'),
(80, 'Richard Chandra Tjiang', 11181073, 5, '2021-11-25', '12:59:04', '13:00:44'),
(81, 'Yosias ', 4181081, 23, '2021-11-25', '13:06:30', '13:06:49'),
(82, 'Yosias ', 4181081, 23, '2021-12-03', '13:52:18', '13:57:20'),
(83, 'qwertyuiop', 14567890, 4, '2021-12-06', '16:29:47', '16:41:41'),
(84, 'qqq', 111, 3, '2021-12-06', '16:39:28', '16:39:49'),
(85, 'Richard Chandra Tjiang', 11181073, 5, '2021-12-06', '16:40:20', '00:00:00'),
(86, 'Tjiang Chandra Richard', 17, 19, '2021-12-06', '16:42:52', '00:00:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users_logs`
--
ALTER TABLE `users_logs`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=47;

--
-- AUTO_INCREMENT for table `users_logs`
--
ALTER TABLE `users_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=87;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
