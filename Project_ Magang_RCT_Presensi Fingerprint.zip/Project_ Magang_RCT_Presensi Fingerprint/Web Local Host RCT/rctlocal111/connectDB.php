<?php
/* Settingan Konektivitas ke database */
	$servername = "localhost"; //nama servername, karena masih local jadi localhost
    $username = "root";		// username database, karena offline dan default jadi isinya Root
    $password = "";			// Password, karena tidak di setting jadi kosong
    $dbname = "biometricattendace"; //Nama databsenya, 
    
	$conn = mysqli_connect($servername, $username, $password, $dbname); 
	
	if ($conn->connect_error) {
        die("Database Connection failed: " . $conn->connect_error); //apabila koneksi error maka akan diberitahu bahwa koneksi ke db error
    }
?>