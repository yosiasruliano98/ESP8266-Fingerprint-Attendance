<?php 
require_once'connectDB.php';

function count_user_checkin_this_month($name) {
    $first_day = date('Y-m-01');
    $last_day = date('Y-m-t');
    return count_user_checkin_between($name, $first_day, $last_day);
}

// fungsi untuk menghitung checkin antara $start dan $end
// format $start dan $end harus Y-m-d ( tahun-bulan-tanggal )
const TIMEIN_NOT_LATE = "08:00:00";
const TIMEOUT = "16:00:00";

function count_user_checkin_between($name, $start, $end) {
    global $conn;
    $timein = TIMEIN_NOT_LATE;
    $timeout = TIMEOUT;

    $items = "
    SELECT
        users_logs.username,
        users_logs.checkindate,
        users_logs.timein,
        users_logs.timeout,
        TIMEDIFF(users_logs.timeout, users_logs.timein) as diff
    FROM
        users_logs
    WHERE
        checkindate BETWEEN DATE(?) and DATE(?)
        and
        username=?
    ";

    $sql = "
    SELECT
        COUNT(checkindate) as TOTAL,
        COUNT(CASE WHEN timein <= TIME('$timein') THEN 1 END) as Datang_Tepat_Waktu,
        COUNT(CASE WHEN timein > TIME('$timein') THEN 1 END) as Telat,
        COUNT(CASE WHEN timeout < TIME('$timeout') THEN 1 END) as Pulang_Duluan_Pada_Jam_Kerja,
        COUNT(CASE WHEN timeout >= TIME('$timeout') THEN 1 END) as Pulang_Tepat_waktu,
        COUNT(CASE WHEN (diff BETWEEN TIME('04:00:00') and TIME('05:00:00')) THEN 1 END) as Masuk_Kerja_Setengah_Hari
    FROM
        ($items) as items
    ";

    {
        $result = mysqli_stmt_init($conn);
        if (!mysqli_stmt_prepare($result, $sql)) {
            echo $sql."<br/>";
            print_r(mysqli_error_list($conn));
            echo '<p class="error">SQL Error</p>';
        }
        else{
            mysqli_stmt_bind_param($result, 'sss',$start,$end, $name);
            //echo $start."<br/>".$end."<br/>";
            mysqli_stmt_execute($result);
            $resultl = mysqli_stmt_get_result($result);
            if ( $resultl ) {
                if (mysqli_num_rows($resultl) > 0){
                    $row = mysqli_fetch_assoc($resultl);

                    return $row;
                }
            }
            return 0;
        }
    };
}

// contoh ngambil bulan kemaren
// echo count_user_checkin_between('dika', date('Y-m-01', strtotime('-1 month')), date('Y-m-t', strtotime('-1 month')));
?>
